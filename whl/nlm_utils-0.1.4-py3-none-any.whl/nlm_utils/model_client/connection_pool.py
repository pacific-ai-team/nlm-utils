import urllib3

connection_pool = urllib3.PoolManager(maxsize=20)
